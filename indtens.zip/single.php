<?php
/**
 * Theme Single Post Section for our theme.
 *
 * @package ThemeGrill
 * @subpackage Freedom
 * @since Freedom 1.0
 */

get_header(); ?>

	<?php do_action( 'freedom_before_body_content' ); ?>
	
	<div id="primary">
		<div id="content" class="clearfix">

			<?php while ( have_posts() ) : the_post(); ?>

				<?php get_template_part( 'content', 'single' ); ?>

				<?php get_template_part( 'navigation', 'single' ); ?>

				<?php
					do_action( 'freedom_before_comments_template' );
					if ( comments_open() || '0' != get_comments_number() )
						comments_template();
	      		do_action ( 'freedom_after_comments_template' );
				?>

			<?php endwhile; ?>

		</div><!-- #content -->
	</div><!-- #primary -->

	<?php //freedom_sidebar_select(); ?>
	<?php get_sidebar(); ?>
	<?php do_action( 'freedom_after_body_content' ); ?>

<?php get_footer(); ?>